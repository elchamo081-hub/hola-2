def main():
    print("Hello from dashboardjose!")


if __name__ == "__main__":
    main()
